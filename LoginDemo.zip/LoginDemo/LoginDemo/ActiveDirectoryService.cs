﻿using LoginDemo.Models;
using System.DirectoryServices.AccountManagement;

namespace LoginDemo
{
    public static class ActiveDirectoryService
    {
        public static bool ValidateCredentials(string domain, string userName, string password)
        {
            using (var context = new PrincipalContext(ContextType.Domain, domain))
            {
                return context.ValidateCredentials(userName, password);
            }
        }

        public static User GetUser(string domain, string userName)
        {
            User result = null;
            using (var context = new PrincipalContext(ContextType.Domain, domain))
            {
                var user = UserPrincipal.FindByIdentity(context, userName);
                if (user != null)
                {
                    result = new User
                    {
                        FIRST_NAME = user.GivenName,
                        LAST_NAME = user.Surname
                    };
                }
            }
            return result;
        }
    }
}
